--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2 (Ubuntu 14.2-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.2 (Ubuntu 14.2-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stock_development;
--
-- Name: stock_development; Type: DATABASE; Schema: -; Owner: emmanuelkamala
--

CREATE DATABASE stock_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE stock_development OWNER TO emmanuelkamala;

\connect stock_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO emmanuelkamala;

--
-- Name: batches; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.batches (
    id bigint NOT NULL,
    batch_no integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    flock_type character varying
);


ALTER TABLE public.batches OWNER TO emmanuelkamala;

--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batches_id_seq OWNER TO emmanuelkamala;

--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.expenses (
    id bigint NOT NULL,
    date date,
    category character varying,
    quantity integer,
    unit_price integer,
    total_amount integer,
    description text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    batch_id bigint
);


ALTER TABLE public.expenses OWNER TO emmanuelkamala;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expenses_id_seq OWNER TO emmanuelkamala;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: financial_searches; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.financial_searches (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.financial_searches OWNER TO emmanuelkamala;

--
-- Name: financial_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.financial_searches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financial_searches_id_seq OWNER TO emmanuelkamala;

--
-- Name: financial_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.financial_searches_id_seq OWNED BY public.financial_searches.id;


--
-- Name: fixed_expenses; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.fixed_expenses (
    id bigint NOT NULL,
    date_in date,
    type_of_expense character varying,
    cost integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    quantity integer,
    description text,
    total_cost integer
);


ALTER TABLE public.fixed_expenses OWNER TO emmanuelkamala;

--
-- Name: fixed_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.fixed_expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fixed_expenses_id_seq OWNER TO emmanuelkamala;

--
-- Name: fixed_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.fixed_expenses_id_seq OWNED BY public.fixed_expenses.id;


--
-- Name: flocks; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.flocks (
    id bigint NOT NULL,
    batch_no integer,
    date_in timestamp without time zone,
    retirement_date date,
    source character varying,
    initial_stock integer,
    died_stock integer,
    notes text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    status character varying,
    batch_id bigint,
    sold_stock integer DEFAULT 0
);


ALTER TABLE public.flocks OWNER TO emmanuelkamala;

--
-- Name: flocks_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.flocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flocks_id_seq OWNER TO emmanuelkamala;

--
-- Name: flocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.flocks_id_seq OWNED BY public.flocks.id;


--
-- Name: incomes; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.incomes (
    id bigint NOT NULL,
    date date,
    category character varying,
    quantity integer,
    unit_price integer,
    total_amount integer,
    description text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    batch_id bigint
);


ALTER TABLE public.incomes OWNER TO emmanuelkamala;

--
-- Name: incomes_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.incomes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incomes_id_seq OWNER TO emmanuelkamala;

--
-- Name: incomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.incomes_id_seq OWNED BY public.incomes.id;


--
-- Name: report_searches; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.report_searches (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.report_searches OWNER TO emmanuelkamala;

--
-- Name: report_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.report_searches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_searches_id_seq OWNER TO emmanuelkamala;

--
-- Name: report_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.report_searches_id_seq OWNED BY public.report_searches.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO emmanuelkamala;

--
-- Name: statuses; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.statuses OWNER TO emmanuelkamala;

--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statuses_id_seq OWNER TO emmanuelkamala;

--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: emmanuelkamala
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    username character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO emmanuelkamala;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: emmanuelkamala
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO emmanuelkamala;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: emmanuelkamala
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: financial_searches id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.financial_searches ALTER COLUMN id SET DEFAULT nextval('public.financial_searches_id_seq'::regclass);


--
-- Name: fixed_expenses id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.fixed_expenses ALTER COLUMN id SET DEFAULT nextval('public.fixed_expenses_id_seq'::regclass);


--
-- Name: flocks id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.flocks ALTER COLUMN id SET DEFAULT nextval('public.flocks_id_seq'::regclass);


--
-- Name: incomes id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.incomes ALTER COLUMN id SET DEFAULT nextval('public.incomes_id_seq'::regclass);


--
-- Name: report_searches id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.report_searches ALTER COLUMN id SET DEFAULT nextval('public.report_searches_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.batches (id, batch_no, created_at, updated_at, flock_type) FROM stdin;
\.
COPY public.batches (id, batch_no, created_at, updated_at, flock_type) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.expenses (id, date, category, quantity, unit_price, total_amount, description, created_at, updated_at, batch_id) FROM stdin;
\.
COPY public.expenses (id, date, category, quantity, unit_price, total_amount, description, created_at, updated_at, batch_id) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: financial_searches; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.financial_searches (id, created_at, updated_at) FROM stdin;
\.
COPY public.financial_searches (id, created_at, updated_at) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: fixed_expenses; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.fixed_expenses (id, date_in, type_of_expense, cost, created_at, updated_at, quantity, description, total_cost) FROM stdin;
\.
COPY public.fixed_expenses (id, date_in, type_of_expense, cost, created_at, updated_at, quantity, description, total_cost) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: flocks; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.flocks (id, batch_no, date_in, retirement_date, source, initial_stock, died_stock, notes, created_at, updated_at, status, batch_id, sold_stock) FROM stdin;
\.
COPY public.flocks (id, batch_no, date_in, retirement_date, source, initial_stock, died_stock, notes, created_at, updated_at, status, batch_id, sold_stock) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: incomes; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.incomes (id, date, category, quantity, unit_price, total_amount, description, created_at, updated_at, batch_id) FROM stdin;
\.
COPY public.incomes (id, date, category, quantity, unit_price, total_amount, description, created_at, updated_at, batch_id) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: report_searches; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.report_searches (id, created_at, updated_at) FROM stdin;
\.
COPY public.report_searches (id, created_at, updated_at) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.statuses (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.statuses (id, name, created_at, updated_at) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: emmanuelkamala
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, username, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, username, created_at, updated_at) FROM '$$PATH$$/3383.dat';

--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.batches_id_seq', 58, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.expenses_id_seq', 544, true);


--
-- Name: financial_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.financial_searches_id_seq', 1, false);


--
-- Name: fixed_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.fixed_expenses_id_seq', 1, true);


--
-- Name: flocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.flocks_id_seq', 55, true);


--
-- Name: incomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.incomes_id_seq', 707, true);


--
-- Name: report_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.report_searches_id_seq', 1, false);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.statuses_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: emmanuelkamala
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: financial_searches financial_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.financial_searches
    ADD CONSTRAINT financial_searches_pkey PRIMARY KEY (id);


--
-- Name: fixed_expenses fixed_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.fixed_expenses
    ADD CONSTRAINT fixed_expenses_pkey PRIMARY KEY (id);


--
-- Name: flocks flocks_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.flocks
    ADD CONSTRAINT flocks_pkey PRIMARY KEY (id);


--
-- Name: incomes incomes_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_pkey PRIMARY KEY (id);


--
-- Name: report_searches report_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.report_searches
    ADD CONSTRAINT report_searches_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_expenses_on_batch_id; Type: INDEX; Schema: public; Owner: emmanuelkamala
--

CREATE INDEX index_expenses_on_batch_id ON public.expenses USING btree (batch_id);


--
-- Name: index_flocks_on_batch_id; Type: INDEX; Schema: public; Owner: emmanuelkamala
--

CREATE INDEX index_flocks_on_batch_id ON public.flocks USING btree (batch_id);


--
-- Name: index_incomes_on_batch_id; Type: INDEX; Schema: public; Owner: emmanuelkamala
--

CREATE INDEX index_incomes_on_batch_id ON public.incomes USING btree (batch_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: emmanuelkamala
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: emmanuelkamala
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: expenses fk_rails_4a49dcc6f9; Type: FK CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT fk_rails_4a49dcc6f9 FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: incomes fk_rails_a0907e92ed; Type: FK CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT fk_rails_a0907e92ed FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: flocks fk_rails_bf7a1cb1f5; Type: FK CONSTRAINT; Schema: public; Owner: emmanuelkamala
--

ALTER TABLE ONLY public.flocks
    ADD CONSTRAINT fk_rails_bf7a1cb1f5 FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- PostgreSQL database dump complete
--

